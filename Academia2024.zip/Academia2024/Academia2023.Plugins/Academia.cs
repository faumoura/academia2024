﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;

namespace Academia2024.Plugins
{
    public class Academia : IPlugin //IPlugin é interface que precisa de um metodo de execute
    {
        private IPluginExecutionContext context { get; set; }
        private IOrganizationServiceFactory serviceFactory { get; set; }
        private IOrganizationService serviceUsuario { get; set; }
        private IOrganizationService serviceGlobal { get; set; }
        private ITracingService tracing { get; set; }
        public void Execute(IServiceProvider serviceProvider)
        {
            #region "Cabeçalho essenciais para o plugin"            
            //https://docs.microsoft.com/en-us/dotnet/api/microsoft.xrm.sdk.ipluginexecutioncontext?view=dynamics-general-ce-9
            //Contexto de execução
            IPluginExecutionContext context = (IPluginExecutionContext)serviceProvider.GetService(typeof(IPluginExecutionContext));
            //Fabrica de conexões
            IOrganizationServiceFactory serviceFactory = (IOrganizationServiceFactory)serviceProvider.GetService(typeof(IOrganizationServiceFactory));
            //Service no contexto do usuário
            serviceUsuario = serviceFactory.CreateOrganizationService(context.UserId);
            //Service no contexto Global (usuário System)
            serviceGlobal = serviceFactory.CreateOrganizationService(null);
            //Trancing utilizado para reastreamento de mensagem durante o processo
            tracing = (ITracingService)serviceProvider.GetService(typeof(ITracingService));
            #endregion

            #region "Verificador de profundidade para evitar loop"
            if (context.Depth > 1) return;
            #endregion

            #region "Mensagens de Chamadas"
            if (context.MessageName.ToLower().Trim() == "create")
            {
                if (!context.InputParameters.Contains("Target") && !(context.InputParameters["Target"] is Entity)) return;
                Entity entityContext = context.InputParameters["Target"] as Entity;
                if (context.Stage == (int)Helper.EventStage.PreOperation && context.Mode == (int)Helper.ExecutionMode.Synchronous)
                {
                    this.CalcularValorTotal(entityContext);
                }
            }

            if (context.MessageName.ToLower().Trim() == "update")
            {
                if (!context.InputParameters.Contains("Target") && !(context.InputParameters["Target"] is Entity)) return;
                Entity entityContext = context.InputParameters["Target"] as Entity;
                if (context.PreEntityImages.Contains("PreImage") && context.PreEntityImages["PreImage"] is Entity)
                {
                    Entity preImage = context.PreEntityImages["PreImage"] as Entity;
                    if (context.Stage == (int)Helper.EventStage.PreOperation && context.Mode == (int)Helper.ExecutionMode.Synchronous)
                    {
                        if (entityContext.Contains("academia_categoriadefilmes") || entityContext.Contains("academia_quantotempoconhecealocadora"))
                            this.CalcularValorTotal(entityContext, preImage);
                    }
                }
            }

            
            #endregion
        }
        public void CalcularValorTotal(Entity entityContext, Entity preImage = null)
        {
            Guid idCategoria = entityContext.Contains("academia_categoriadefilmes") ? entityContext.GetAttributeValue<EntityReference>("academia_categoriadefilmes").Id : preImage.GetAttributeValue<EntityReference>("academia_categoriadefilmes").Id;

            QueryExpression query = new QueryExpression();
            query.EntityName = "academia_categoriadefilme";
            query.ColumnSet = new ColumnSet("academia_preco");
            query.Criteria.AddCondition("academia_categoriadefilmeid", ConditionOperator.Equal, idCategoria);
            EntityCollection categoriaFilmesCollection = serviceGlobal.RetrieveMultiple(query);
            Entity categoriaFilmes = categoriaFilmesCollection.Entities.FirstOrDefault();
            Money precoCategoria = new Money(0);

            if (categoriaFilmes != null && categoriaFilmes.Contains("academia_preco") && categoriaFilmes["academia_preco"] != null)
            {
                precoCategoria = categoriaFilmes.GetAttributeValue<Money>("academia_preco");
                entityContext["academia_precoaluguel"] = precoCategoria;

            }

            Money desconto = new Money(0);
            int tempoColadora = entityContext.Contains("academia_quantotempoconhecealocadora") ? entityContext.GetAttributeValue<OptionSetValue>("academia_quantotempoconhecealocadora").Value : preImage.GetAttributeValue<OptionSetValue>("academia_quantotempoconhecealocadora").Value;
            switch (tempoColadora)
            {
                case 645870000: //menos de um mes
                    desconto = new Money(2);
                    break;
                case 645870001: //um mes
                    desconto = new Money(3);
                    break;
                case 645870002: //tres meses
                    desconto = new Money(4);
                    break;
                case 645870003: //seis meses
                    desconto = new Money(5);
                    break;
                case 645870004: //um ano ou mais meses
                    desconto = new Money(6);
                    break;
                default:
                    break;
            }

            entityContext["academia_desconto"] = desconto;

            entityContext["academia_valortotal"] = new Money(precoCategoria.Value - desconto.Value);


            tracing.Trace("teste");
        }

        
    }
}
