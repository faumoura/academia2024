﻿if (typeof Academia === "undefined") {
    Academia = {};
}

Academia.Contato = {
    campoCPF: "academia_cpf",
    campoCEP: "address1_postalcode",
    //definicao de contexto
    formContext: {},
    saveContext: {},

    OnLoad: function (executeContext) {
        Academia.Contato.formContext = executeContext.getFormContext();
        Academia.Contato.OnChange();
    },

    OnSave: function (formContext) {
        Academia.Contato.formContext = formContext;
    },

    OnChange: function () {
        Academia.Contato.formContext.getAttribute(Academia.Contato.campoCPF).addOnChange(Academia.Contato.ValidaCPF);
        Academia.Contato.formContext.getAttribute(Academia.Contato.campoCEP).addOnChange(Academia.Contato.BuscarCEP);
    },

    BuscarCEP() {
        let cep = Academia.Contato.formContext.getAttribute(Academia.Contato.campoCEP).getValue();
        var url = "https://viacep.com.br/ws/" + cep + "/json/";

        // Fazer requisiÃ§Ã£o GET para a API ViaCEP
        var req = new XMLHttpRequest();
        req.open("GET", url, false);
        req.send();

        if (req.status === 200) {
            var endereco = JSON.parse(req.responseText);
            Academia.Contato.formContext.getAttribute("address1_line1").setValue(endereco.logradouro);
            Academia.Contato.formContext.getAttribute("address1_line2").setValue(endereco.bairro);
            Academia.Contato.formContext.getAttribute("address1_city").setValue(endereco.localidade);
            Academia.Contato.formContext.getAttribute("address1_stateorprovince").setValue(endereco.uf);
        } else {
            console.error("Erro ao buscar CEP:", req.status);
            return null;
        }
    },

    ValidaCPF: function () {
        debugger;
        let strCPF = Academia.Contato.formContext.getAttribute(Academia.Contato.campoCPF).getValue();
        let isValid = Academia.Contato.ValidadorCPF(strCPF);

        if (isValid) {
            Academia.Contato.formContext.getControl(Academia.Contato.campoCPF).clearNotification();
        } else {
            Academia.Contato.formContext.getControl(Academia.Contato.campoCPF).setNotification("CPF inválido");
        }
    },

    ValidadorCPF: function (strCPF) {
        strCPF = strCPF.replace(/[^\d]/g, ""); // Remove caracteres nÃ£o numÃ©ricos
        var Soma;
        var Resto;
        Soma = 0;
        if (strCPF == "00000000000") return false;
        if (strCPF.length != 11) return false;

        for (i = 1; i <= 9; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (11 - i);
        Resto = (Soma * 10) % 11;

        if (Resto == 10 || Resto == 11) Resto = 0;
        if (Resto != parseInt(strCPF.substring(9, 10))) return false;

        Soma = 0;
        for (i = 1; i <= 10; i++) Soma = Soma + parseInt(strCPF.substring(i - 1, i)) * (12 - i);
        Resto = (Soma * 10) % 11;

        if (Resto == 10 || Resto == 11) Resto = 0;
        if (Resto != parseInt(strCPF.substring(10, 11))) return false;
        return true;
    },
};