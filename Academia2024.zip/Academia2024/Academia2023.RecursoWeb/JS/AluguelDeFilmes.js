﻿if (typeof (Academia) == "undefined") { Academia = {}; }

Academia.AluguelDeFilmes = {
    //definicao de contexto
    formContext: {},
    saveContext: {},
    globalContext: Xrm.Utility.getGlobalContext(),

    //definicao de campos
    campoConhece: "academia_quantotempoconhecealocadora",
    campoNome: "academia_nomedofilme",
    campoContato: "academia_contato",
    campoCategoria: "academia_categoriadefilmes",
    campoDuplicar: "academia_duplicar",


    OnLoad: function (executionContext) {
        Academia.AluguelDeFilmes.formContext = executionContext.getFormContext();
        Academia.AluguelDeFilmes.OnChange();

        Academia.AluguelDeFilmes.TornarObrigatorio();

    },

    /**
    * Função responsável pela configuração dos eventos de modificações dos campos, ela deve sempre ser chamada no carregamento da página
    */
    OnChange: function (formContext) {
        Academia.AluguelDeFilmes.formContext.getAttribute(Academia.AluguelDeFilmes.campoDuplicar).addOnChange(Academia.AluguelDeFilmes.Duplicar);

    },

    OnSave: function (formContext) {
        Academia.AluguelDeFilmes.saveContext = executionContext.getFormContext();
    },

    TornarObrigatorio: async function (formContext) {
        Academia.AluguelDeFilmes.formContext.getAttribute(Academia.AluguelDeFilmes.campoCategoria).setRequiredLevel("required");
        Academia.AluguelDeFilmes.formContext.getAttribute(Academia.AluguelDeFilmes.campoNome).setRequiredLevel("required");
        Academia.AluguelDeFilmes.formContext.getAttribute(Academia.AluguelDeFilmes.campoConhece).setRequiredLevel("required");
    },


    Duplicar: async function (formContext) {
        let duplicar = Academia.AluguelDeFilmes.formContext.getAttribute(Academia.AluguelDeFilmes.campoDuplicar).getValue();
        if (duplicar == true) {
                var record = {};
            record["academia_Contato@odata.bind"] = `/contacts(${Academia.AluguelDeFilmes.formContext.getAttribute(Academia.AluguelDeFilmes.campoContato).getValue()[0].id.replace("{", "").replace("}", "")})`;

                await Xrm.WebApi.createRecord("academia_alugueldefilmes", record).then(
                    function success(result) { },
                    function (error) {
                        console.log(error.message);
                    }
                );
        }
    },


}